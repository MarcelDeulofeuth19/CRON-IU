#!/bin/bash
set -euo pipefail

# --- Variables de Configuración ---
# Nombre del contenedor Docker
CONTAINER_NAME="crontab-ui"
# Puerto en el host para acceder a Crontab UI
HOST_PORT=8000
# Credenciales de autenticación básica (Considera usar variables de entorno o un gestor de secretos para producción)
BASIC_AUTH_USER="${CRONTAB_UI_USER:-admin}"
BASIC_AUTH_PWD="${CRONTAB_UI_PASSWORD:-umeAK1eWI}" # Contraseña por defecto si no se define la variable de entorno
# Imagen Docker y etiqueta (usar 'latest' o una versión específica)
IMAGE_NAME="alseambusher/crontab-ui:latest"
# Directorio en el host para persistir la base de datos de Crontab UI
# Esto es crucial para que tus crontabs no se pierdan si el contenedor se recrea.
CRONTAB_DB_HOST_PATH="${PWD}/crontab_ui_data" # Se creará una carpeta 'crontab_ui_data' en el directorio actual
# Política de reinicio del contenedor
RESTART_POLICY="unless-stopped"

# --- Verificaciones Previas ---
if ! command -v docker &> /dev/null; then
    echo "Error: Docker no está instalado o no se encuentra en el PATH." >&2
    exit 1
fi

# Asegurarse de que el directorio para el volumen de datos exista
mkdir -p "${CRONTAB_DB_HOST_PATH}"
echo "Directorio de datos para Crontab UI: ${CRONTAB_DB_HOST_PATH}"

# --- Gestión del Contenedor Existente ---
if docker ps -a --format '{{.Names}}' | grep -qw "${CONTAINER_NAME}"; then
    echo "El contenedor '${CONTAINER_NAME}' ya existe."
    read -p "¿Deseas detenerlo y eliminarlo para relanzarlo? (s/N): " CONFIRM_RECREATE
    if [[ "${CONFIRM_RECREATE,,}" == "s" ]]; then
        echo "Deteniendo y eliminando el contenedor '${CONTAINER_NAME}'..."
        docker stop "${CONTAINER_NAME}" >/dev/null && docker rm "${CONTAINER_NAME}" >/dev/null
        echo "Contenedor anterior eliminado."
    else
        echo "Operación cancelada. El contenedor existente '${CONTAINER_NAME}' no se modificará."
        exit 0
    fi
fi

# --- Lanzamiento del Contenedor ---
echo "Lanzando el contenedor '${CONTAINER_NAME}' (${IMAGE_NAME})..."
docker run -d \
    --name "${CONTAINER_NAME}" \
    -p "${HOST_PORT}:8000" \
    -e BASIC_AUTH_USER="${BASIC_AUTH_USER}" \
    -e BASIC_AUTH_PWD="${BASIC_AUTH_PWD}" \
    -e TZ="America/Bogota" `# Opcional: Configura la zona horaria para los logs y la UI` \
    -v "${CRONTAB_DB_HOST_PATH}:/crontab-ui/db" `# Persistencia de la base de datos de crontabs` \
    --restart "${RESTART_POLICY}" \
    "${IMAGE_NAME}"

# --- Verificación y Mensaje Final ---
# Pequeña pausa para dar tiempo al contenedor a iniciar
sleep 2

if docker ps --format '{{.Names}}' | grep -qw "${CONTAINER_NAME}"; then
    echo ""
    echo "¡Contenedor '${CONTAINER_NAME}' lanzado con éxito!"
    echo "Puedes acceder a Crontab UI en: http://localhost:${HOST_PORT}"
    echo "Usuario: ${BASIC_AUTH_USER}"
    # Por seguridad, no mostramos la contraseña aquí, pero recuérdala.
else
    echo ""
    echo "Error: El contenedor '${CONTAINER_NAME}' no parece estar corriendo." >&2
    echo "Revisa los logs con: docker logs ${CONTAINER_NAME}"
    exit 1
fi
